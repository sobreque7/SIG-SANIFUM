# routes_servicios.py
from flask import Blueprint, request, jsonify
from datetime import datetime
from models import (
    db,
    Servicio,
    Cliente,
    Tecnico,
    Factura,
    IndicadorServicio,
    HistorialServicio,
)
from asignador import asignar_tecnico_a_servicio

servicios_bp = Blueprint("servicios", __name__)


# =========================
#   CREAR SERVICIO (POST)
# =========================
@servicios_bp.route("/servicios", methods=["POST"])
def crear_servicio():
    data = request.json or {}

    if "id_cliente" not in data:
        return jsonify({"error": "id_cliente es obligatorio"}), 400

    cliente = Cliente.query.get_or_404(data["id_cliente"])

    # --- PRIORIDAD automática simple ---
    prioridad = data.get("prioridad")
    tipo_plaga = data.get("tipo_plaga")

    if not prioridad:
        if cliente.tipo_cliente and cliente.tipo_cliente.lower() == "industrial":
            prioridad = "alta"
        elif tipo_plaga and tipo_plaga.lower() in ["roedores", "cucarachas"]:
            prioridad = "alta"
        else:
            prioridad = "media"

    # --- Parsear fecha y hora ---
    fecha_prog = None
    hora_prog = None

    if data.get("fecha_programada"):
        try:
            fecha_prog = datetime.strptime(data["fecha_programada"], "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"error": "fecha_programada debe ser YYYY-MM-DD"}), 400

    if data.get("hora_programada"):
        try:
            hora_prog = datetime.strptime(data["hora_programada"], "%H:%M").time()
        except ValueError:
            return jsonify({"error": "hora_programada debe ser HH:MM"}), 400

    servicio = Servicio(
        cliente=cliente,
        tipo_plaga=tipo_plaga,
        tipo_servicio=data.get("tipo_servicio"),
        prioridad=prioridad,
        fecha_programada=fecha_prog,
        hora_programada=hora_prog,
        duracion_estimada=data.get("duracion_estimada", 60),
    )

    db.session.add(servicio)
    db.session.commit()  # aquí ya tiene id_servicio

    # --- Asignación automática del técnico más cercano ---
    asign = asignar_tecnico_a_servicio(servicio)

    return jsonify(
        {
            "mensaje": "Servicio creado",
            "id_servicio": servicio.id_servicio,
            "prioridad": servicio.prioridad,
            "id_asignacion": asign.id_asignacion if asign else None,
        }
    ), 201


# =========================
#   LISTAR SERVICIOS (GET)
# =========================
@servicios_bp.route("/servicios", methods=["GET"])
def listar_servicios():
    servicios = Servicio.query.all()
    res = []

    for s in servicios:
        nombre_tecnico = None
        if s.asignaciones:
            primera_asign = s.asignaciones[0]
            if primera_asign.tecnico:
                nombre_tecnico = primera_asign.tecnico.nombre

        res.append(
            {
                "id_servicio": s.id_servicio,
                "cliente": s.cliente.nombre_razon_social if s.cliente else None,
                "tipo_servicio": s.tipo_servicio,
                "tipo_plaga": s.tipo_plaga,
                "prioridad": s.prioridad,
                "fecha_programada": s.fecha_programada.isoformat()
                if s.fecha_programada
                else None,
                "hora_programada": s.hora_programada.strftime("%H:%M")
                if s.hora_programada
                else None,
                "estado": s.estado_servicio,
                "tecnico_asignado": nombre_tecnico,
            }
        )

    return jsonify(res), 200


# =========================
#   OBTENER SERVICIO (GET)
# =========================
@servicios_bp.route("/servicios/<int:id_servicio>", methods=["GET"])
def obtener_servicio(id_servicio):
    s = Servicio.query.get_or_404(id_servicio)

    nombre_tecnico = None
    if s.asignaciones:
        primera_asign = s.asignaciones[0]
        if primera_asign.tecnico:
            nombre_tecnico = primera_asign.tecnico.nombre

    data = {
        "id_servicio": s.id_servicio,
        "id_cliente": s.id_cliente,
        "cliente": s.cliente.nombre_razon_social if s.cliente else None,
        "tipo_servicio": s.tipo_servicio,
        "tipo_plaga": s.tipo_plaga,
        "prioridad": s.prioridad,
        "fecha_programada": s.fecha_programada.isoformat()
        if s.fecha_programada
        else None,
        "hora_programada": s.hora_programada.strftime("%H:%M")
        if s.hora_programada
        else None,
        "estado": s.estado_servicio,
        "tecnico_asignado": nombre_tecnico,
    }

    return jsonify(data), 200


# =========================
#  ACTUALIZAR SERVICIO (PUT)
#  Si pasa a "realizado": genera Factura + Indicador
# =========================
@servicios_bp.route("/servicios/<int:id_servicio>", methods=["PUT"])
def actualizar_servicio(id_servicio):
    servicio = Servicio.query.get_or_404(id_servicio)
    data = request.json or {}

    # Actualizar campos básicos si vienen
    if "estado_servicio" in data:
        servicio.estado_servicio = data["estado_servicio"]

    if "prioridad" in data:
        servicio.prioridad = data["prioridad"]

    # Podríamos permitir actualizar fecha/hora también:
    if "fecha_programada" in data and data["fecha_programada"]:
        try:
            servicio.fecha_programada = datetime.strptime(
                data["fecha_programada"], "%Y-%m-%d"
            ).date()
        except ValueError:
            return jsonify({"error": "fecha_programada debe ser YYYY-MM-DD"}), 400

    if "hora_programada" in data and data["hora_programada"]:
        try:
            servicio.hora_programada = datetime.strptime(
                data["hora_programada"], "%H:%M"
            ).time()
        except ValueError:
            return jsonify({"error": "hora_programada debe ser HH:MM"}), 400

    db.session.commit()

    # Si el servicio ha pasado a "realizado", automatizamos factura + indicador
    if servicio.estado_servicio == "realizado":
        ahora = datetime.utcnow()

        # --- Factura automática ---
        if servicio.factura is None:
            factura = Factura(
                servicio=servicio,
                numero_documento=data.get("numero_documento"),
                monto=data.get("monto", 45000),  # monto por defecto
                tipo_documento=data.get("tipo_documento", "boleta"),
                medio_pago=data.get("medio_pago", "transferencia"),
                estado_pago="pendiente",
                fecha_emision=ahora,
            )
            db.session.add(factura)

        # --- Indicador automático ---
        if servicio.indicador is None:
            tiempo_resp = None
            if servicio.fecha_creacion:
                delta = ahora - servicio.fecha_creacion
                tiempo_resp = round(delta.total_seconds() / 3600.0, 2)

            indicador = IndicadorServicio(
                servicio=servicio,
                tiempo_respuesta_horas=tiempo_resp,
                cumplimiento_agenda=True,     # suposición por defecto
                reprogramado=False,           # se podría ajustar si hubo cambios
                satisfaccion_cliente_pct=100, # valor base
            )
            db.session.add(indicador)

        db.session.commit()

    return jsonify(
        {
            "mensaje": "Servicio actualizado",
            "id_servicio": servicio.id_servicio,
            "estado_servicio": servicio.estado_servicio,
        }
    ), 200


# =========================
#   HISTORIAL DEL SERVICIO
# =========================

@servicios_bp.route("/servicios/<int:id_servicio>/historial", methods=["GET"])
def obtener_historial_servicio(id_servicio):
    Servicio.query.get_or_404(id_servicio)

    eventos = (
        HistorialServicio.query.filter_by(id_servicio=id_servicio)
        .order_by(HistorialServicio.fecha_evento.asc())
        .all()
    )

    resultado = []
    for e in eventos:
        resultado.append(
            {
                "id_evento": e.id_evento,
                "fecha_evento": e.fecha_evento.strftime("%Y-%m-%d %H:%M"),
                "tipo_evento": e.tipo_evento,
                "descripcion": e.descripcion,
                "motivo": e.motivo,
                "url_evidencia": e.url_evidencia,
                "registrado_por": e.registrado_por,
            }
        )

    return jsonify(resultado), 200


@servicios_bp.route("/servicios/<int:id_servicio>/historial", methods=["POST"])
def agregar_evento_historial(id_servicio):
    Servicio.query.get_or_404(id_servicio)
    data = request.json or {}

    if not data.get("tipo_evento"):
        return jsonify({"error": "tipo_evento es obligatorio"}), 400

    nuevo = HistorialServicio(
        id_servicio=id_servicio,
        tipo_evento=data.get("tipo_evento"),
        descripcion=data.get("descripcion"),
        motivo=data.get("motivo"),
        url_evidencia=data.get("url_evidencia"),
        registrado_por=data.get("registrado_por"),
    )

    db.session.add(nuevo)
    db.session.commit()

    return jsonify(
        {
            "mensaje": "Evento agregado al historial",
            "id_evento": nuevo.id_evento,
        }
    ), 201
