from flask import Blueprint, jsonify
from models import db, Factura

facturas_bp = Blueprint("facturas", __name__)

@facturas_bp.route("/facturas", methods=["GET"])
def listar_facturas():
    facturas = Factura.query.all()
    res = []

    for f in facturas:
        servicio = f.servicio
        cliente = servicio.cliente if servicio else None

        res.append({
            "id_factura": f.id_factura,
            "numero_documento": f.numero_documento,
            "monto": f.monto,
            "fecha_emision": f.fecha_emision.isoformat() if f.fecha_emision else None,
            "tipo_documento": f.tipo_documento,
            "medio_pago": f.medio_pago,
            "estado_pago": f.estado_pago,
            "id_servicio": servicio.id_servicio if servicio else None,
            "cliente": cliente.nombre_razon_social if cliente else None
        })

    return jsonify(res), 200
