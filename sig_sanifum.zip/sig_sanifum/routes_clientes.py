from flask import Blueprint, request, jsonify
from models import db, Cliente

clientes_bp = Blueprint("clientes", __name__)

@clientes_bp.route("/clientes", methods=["POST"])
def crear_cliente():
    data = request.json
    cliente = Cliente(
        nombre_razon_social=data["nombre_razon_social"],
        rut=data["rut"],
        tipo_cliente=data.get("tipo_cliente"),
        tipo_contrato=data.get("tipo_contrato"),
        frecuencia_servicio=data.get("frecuencia_servicio"),
        direccion=data.get("direccion"),
        comuna=data.get("comuna"),
        region=data.get("region"),
        zona_geografica=data.get("zona_geografica")
    )
    db.session.add(cliente)
    db.session.commit()
    return jsonify({"mensaje": "Cliente creado", "id_cliente": cliente.id_cliente}), 201

@clientes_bp.route("/clientes", methods=["GET"])
def listar_clientes():
    clientes = Cliente.query.all()
    resultado = []
    for c in clientes:
        resultado.append({
            "id_cliente": c.id_cliente,
            "nombre_razon_social": c.nombre_razon_social,
            "rut": c.rut,
            "tipo_cliente": c.tipo_cliente,
            "zona_geografica": c.zona_geografica
        })
    return jsonify(resultado)

@clientes_bp.route("/clientes/<int:id_cliente>", methods=["GET"])
def obtener_cliente(id_cliente):
    c = Cliente.query.get_or_404(id_cliente)
    return jsonify({
        "id_cliente": c.id_cliente,
        "nombre_razon_social": c.nombre_razon_social,
        "rut": c.rut,
        "tipo_cliente": c.tipo_cliente,
        "tipo_contrato": c.tipo_contrato,
        "frecuencia_servicio": c.frecuencia_servicio,
        "direccion": c.direccion,
        "comuna": c.comuna,
        "region": c.region,
        "zona_geografica": c.zona_geografica
    })

@clientes_bp.route("/clientes/<int:id_cliente>", methods=["PUT"])
def actualizar_cliente(id_cliente):
    c = Cliente.query.get_or_404(id_cliente)
    data = request.json
    for campo in [
        "nombre_razon_social", "rut", "tipo_cliente", "tipo_contrato",
        "frecuencia_servicio", "direccion", "comuna", "region", "zona_geografica"
    ]:
        if campo in data:
            setattr(c, campo, data[campo])
    db.session.commit()
    return jsonify({"mensaje": "Cliente actualizado"})

@clientes_bp.route("/clientes/<int:id_cliente>", methods=["DELETE"])
def eliminar_cliente(id_cliente):
    c = Cliente.query.get_or_404(id_cliente)
    db.session.delete(c)
    db.session.commit()
    return jsonify({"mensaje": "Cliente eliminado"})
