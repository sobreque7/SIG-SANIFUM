from flask import Blueprint, request, jsonify
from models import db, IndicadorServicio, Servicio

# El nombre de la variable TIENE que ser indicadores_bp
indicadores_bp = Blueprint("indicadores", __name__)

# ------------------------------------
# GET /api/indicadores
# ------------------------------------
@indicadores_bp.route("/indicadores", methods=["GET"])
def listar_indicadores():
    indicadores = IndicadorServicio.query.all()
    res = []

    for ind in indicadores:
        servicio = ind.servicio
        cliente = servicio.cliente if servicio else None

        res.append({
            "id_indicador": ind.id_indicador,
            "id_servicio": servicio.id_servicio if servicio else None,
            "cliente": cliente.nombre_razon_social if cliente else None,
            "tiempo_respuesta_horas": ind.tiempo_respuesta_horas,
            "cumplimiento_agenda": ind.cumplimiento_agenda,
            "reprogramado": ind.reprogramado,
            "satisfaccion_cliente_pct": ind.satisfaccion_cliente_pct,
        })

    return jsonify(res), 200


# ------------------------------------
# GET /api/indicadores/servicio/<id>
# ------------------------------------
@indicadores_bp.route("/indicadores/servicio/<int:id_servicio>", methods=["GET"])
def indicador_por_servicio(id_servicio):
    servicio = Servicio.query.get_or_404(id_servicio)
    if not servicio.indicador:
        return jsonify({"mensaje": "El servicio no tiene indicador asociado"}), 404

    ind = servicio.indicador
    return jsonify({
        "id_indicador": ind.id_indicador,
        "id_servicio": servicio.id_servicio,
        "tiempo_respuesta_horas": ind.tiempo_respuesta_horas,
        "cumplimiento_agenda": ind.cumplimiento_agenda,
        "reprogramado": ind.reprogramado,
        "satisfaccion_cliente_pct": ind.satisfaccion_cliente_pct,
    }), 200


# ------------------------------------
# PUT /api/indicadores/<id_indicador>
# ------------------------------------
@indicadores_bp.route("/indicadores/<int:id_indicador>", methods=["PUT"])
def actualizar_indicador(id_indicador):
    from sqlalchemy.exc import SQLAlchemyError

    ind = IndicadorServicio.query.get_or_404(id_indicador)
    data = request.json or {}

    try:
        if "cumplimiento_agenda" in data:
            ind.cumplimiento_agenda = bool(data["cumplimiento_agenda"])

        if "reprogramado" in data:
            ind.reprogramado = bool(data["reprogramado"])

        if "satisfaccion_cliente_pct" in data:
            valor = data["satisfaccion_cliente_pct"]
            if valor in (None, ""):
                ind.satisfaccion_cliente_pct = None
            else:
                ind.satisfaccion_cliente_pct = int(valor)

        db.session.commit()

        return jsonify({
            "mensaje": "Indicador actualizado",
            "id_indicador": ind.id_indicador,
            "cumplimiento_agenda": ind.cumplimiento_agenda,
            "reprogramado": ind.reprogramado,
            "satisfaccion_cliente_pct": ind.satisfaccion_cliente_pct,
        }), 200

    except (ValueError, TypeError) as e:
        db.session.rollback()
        return jsonify({"error": f"Valor inválido: {str(e)}"}), 400

    except SQLAlchemyError as e:
        db.session.rollback()
        return jsonify({"error": f"Error en BD: {str(e)}"}), 500

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": f"Error inesperado: {str(e)}"}), 500

