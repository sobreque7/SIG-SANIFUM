from flask import Blueprint, request, jsonify
from models import db, Tecnico

tecnicos_bp = Blueprint("tecnicos", __name__)

@tecnicos_bp.route("/tecnicos", methods=["POST"])
def crear_tecnico():
    data = request.json
    t = Tecnico(
        nombre=data["nombre"],
        rut=data["rut"],
        especialidad=data.get("especialidad"),
        zona_asignada=data.get("zona_asignada"),
        activo=data.get("activo", True)
    )
    db.session.add(t)
    db.session.commit()
    return jsonify({"mensaje": "Técnico creado", "id_tecnico": t.id_tecnico}), 201

@tecnicos_bp.route("/tecnicos", methods=["GET"])
def listar_tecnicos():
    tecnicos = Tecnico.query.all()
    return jsonify([
        {
            "id_tecnico": t.id_tecnico,
            "nombre": t.nombre,
            "rut": t.rut,
            "especialidad": t.especialidad,
            "zona_asignada": t.zona_asignada,
            "activo": t.activo
        } for t in tecnicos
    ])

@tecnicos_bp.route("/tecnicos/<int:id_tecnico>", methods=["PUT"])
def actualizar_tecnico(id_tecnico):
    t = Tecnico.query.get_or_404(id_tecnico)
    data = request.json
    for campo in ["nombre", "rut", "especialidad", "zona_asignada", "activo"]:
        if campo in data:
            setattr(t, campo, data[campo])
    db.session.commit()
    return jsonify({"mensaje": "Técnico actualizado"})

@tecnicos_bp.route("/tecnicos/<int:id_tecnico>", methods=["DELETE"])
def eliminar_tecnico(id_tecnico):
    t = Tecnico.query.get_or_404(id_tecnico)
    db.session.delete(t)
    db.session.commit()
    return jsonify({"mensaje": "Técnico eliminado"})
