# asignador.py
from datetime import datetime, timedelta
from models import db, Servicio, Tecnico, Asignacion, Cliente, db
from geo_client import geocodificar_direccion, distancia_km_osrm
import random

# Dirección de la casa matriz de SANIFUM
CASA_MATRIZ_DIRECCION = "Sanifum, Osorno, Región de Los Lagos, Chile"


# ------------------------------
#   Helpers de direcciones
# ------------------------------
def _direccion_cliente(cliente):
    """
    Construye una dirección textual a partir de los campos del cliente.
    Usamos: direccion + comuna + region + 'Chile'.
    """
    if not cliente:
        return None

    partes = []
    if getattr(cliente, "direccion", None):
        partes.append(cliente.direccion)
    if getattr(cliente, "comuna", None):
        partes.append(cliente.comuna)
    if getattr(cliente, "region", None):
        partes.append(cliente.region)

    if not partes:
        return None

    partes.append("Chile")
    return ", ".join(partes)


def _direccion_empresa():
    """
    Dirección base de donde "salen" y a donde "vuelven" los técnicos cada día.
    """
    return CASA_MATRIZ_DIRECCION


def _tecnico_tiene_servicio_en_dia(tecnico: Tecnico, servicio_nuevo: Servicio) -> bool:
    """
    Retorna True si el técnico ya tiene al menos un servicio
    en la misma fecha que servicio_nuevo.fecha_programada.
    """
    if not servicio_nuevo.fecha_programada:
        return False

    return (
        db.session.query(Asignacion)
        .join(Servicio, Asignacion.id_servicio == Servicio.id_servicio)
        .filter(Asignacion.id_tecnico == tecnico.id_tecnico)
        .filter(Servicio.fecha_programada == servicio_nuevo.fecha_programada)
        .count()
        > 0
    )

# ------------------------------
#   Helpers de horario
# ------------------------------
def _ventana_horaria(servicio: Servicio):
    """
    Dado un servicio, retorna (inicio, fin) como datetimes, en base
    a fecha_programada + hora_programada + duracion_estimada.
    Si no tiene hora o fecha, retorna (None, None).
    """
    if not servicio.fecha_programada or not servicio.hora_programada:
        return None, None

    inicio = datetime.combine(servicio.fecha_programada, servicio.hora_programada)
    duracion = servicio.duracion_estimada or 60  # minutos
    fin = inicio + timedelta(minutes=duracion)
    return inicio, fin


def _ventanas_se_solapan(inicio1, fin1, inicio2, fin2):
    """
    Retorna True si dos intervalos [inicio, fin) se solapan en el tiempo.
    """
    if not inicio1 or not inicio2:
        return False
    return inicio1 < fin2 and inicio2 < fin1


def _tecnico_disponible_para_servicio(tecnico: Tecnico, servicio_nuevo: Servicio) -> bool:
    """
    Revisa si un técnico YA tiene servicios ese día y si alguno se cruza
    en horario con el servicio nuevo. Si se cruzan, retorna False.
    """
    nuevo_inicio, nuevo_fin = _ventana_horaria(servicio_nuevo)

    # Si el servicio nuevo no tiene hora o fecha, no podemos chequear solapamientos:
    if not nuevo_inicio:
        return True

    # Buscar todas las asignaciones de ese técnico
    asignaciones = Asignacion.query.filter_by(id_tecnico=tecnico.id_tecnico).all()

    for asig in asignaciones:
        s = asig.servicio
        if not s:
            continue

        # Sólo nos interesa el mismo día
        if s.fecha_programada != servicio_nuevo.fecha_programada:
            continue

        inicio_existente, fin_existente = _ventana_horaria(s)
        if not inicio_existente:
            continue

        if _ventanas_se_solapan(nuevo_inicio, nuevo_fin, inicio_existente, fin_existente):
            # Ya tiene un trabajo que se cruza en horario
            return False

    return True


def _origen_tecnico_en_el_dia(tecnico: Tecnico, servicio_nuevo: Servicio) -> str:
    """
    Determina desde dónde "sale" el técnico para ir al servicio_nuevo:
      - Si YA tiene servicios ese día antes de la hora del nuevo servicio:
          origen = dirección del cliente del último servicio previo.
      - Si NO tiene nada ese día:
          origen = casa matriz.
    """
    nuevo_inicio, _ = _ventana_horaria(servicio_nuevo)
    if not nuevo_inicio:
        # Si el servicio ni siquiera tiene hora, tomamos la empresa como origen
        return _direccion_empresa()

    # Buscar servicios del técnico en el mismo día, ordenados por hora descendente
    asignaciones = (
        Asignacion.query
        .filter_by(id_tecnico=tecnico.id_tecnico)
        .join(Servicio, Asignacion.id_servicio == Servicio.id_servicio)
        .filter(Servicio.fecha_programada == servicio_nuevo.fecha_programada)
        .order_by(Servicio.hora_programada.desc())
        .all()
    )

    for asig in asignaciones:
        s_prev = asig.servicio
        if not s_prev or not s_prev.hora_programada:
            continue

        inicio_prev, _ = _ventana_horaria(s_prev)
        if inicio_prev and inicio_prev <= nuevo_inicio:
            # Este es el último servicio previo en el día
            if s_prev.cliente:
                dir_cli_prev = _direccion_cliente(s_prev.cliente)
                if dir_cli_prev:
                    return dir_cli_prev

    # Si no había servicios previos ese día → sale desde la empresa
    return _direccion_empresa()


# ------------------------------
#   Asignación principal
# ------------------------------
import random
from models import Servicio, Asignacion, Tecnico, Cliente, db  # si ya tienes estos importados, no los repitas


def _tecnico_tiene_servicio_en_dia(tecnico: Tecnico, servicio_nuevo: Servicio) -> bool:
    """
    Retorna True si el técnico ya tiene al menos un servicio
    en la misma fecha que servicio_nuevo.fecha_programada.
    """
    if not servicio_nuevo.fecha_programada:
        return False

    return (
        db.session.query(Asignacion)
        .join(Servicio, Asignacion.id_servicio == Servicio.id_servicio)
        .filter(Asignacion.id_tecnico == tecnico.id_tecnico)
        .filter(Servicio.fecha_programada == servicio_nuevo.fecha_programada)
        .count()
        > 0
    )


def asignar_tecnico_a_servicio(servicio_nuevo: Servicio):
    """
    Asigna un técnico a un servicio nuevo con la siguiente lógica:

    1) Todos los técnicos parten desde la casa matriz.
    2) Mientras existan técnicos activos y disponibles que
       aún no tengan servicios asignados en ese día,
       se elige uno AL AZAR entre ellos (todos salen desde casa matriz).
    3) Cuando todos los técnicos disponibles ya tienen al menos
       un servicio ese día, se asigna por distancia real
       usando la lógica del último servicio del técnico.

    IMPORTANTE: esta función retorna el OBJETO Asignacion (o None),
    para ser compatible con routes_servicios.py.
    """

    if not servicio_nuevo.cliente:
        print("[ASIGNADOR] Servicio sin cliente asociado, no se puede asignar técnico.")
        return None

    # Dirección del cliente
    dir_cliente = _direccion_cliente(servicio_nuevo.cliente)
    if not dir_cliente:
        print("[ASIGNADOR] Cliente sin dirección válida, no se puede asignar técnico.")
        return None

    # Geocodificamos dirección del cliente una sola vez
    lat_cli, lon_cli = geocodificar_direccion(dir_cliente)
    if lat_cli is None or lon_cli is None:
        print(f"[ASIGNADOR] No se pudo geocodificar la dirección del cliente: {dir_cliente}")
        return None

    # Técnicos activos
    tecnicos = Tecnico.query.filter_by(activo=True).all()
    if not tecnicos:
        print("[ASIGNADOR] No hay técnicos activos.")
        return None

    # Filtramos por disponibilidad horaria
    tecnicos_disponibles = [
        t for t in tecnicos
        if _tecnico_disponible_para_servicio(t, servicio_nuevo)
    ]

    if not tecnicos_disponibles:
        print("[ASIGNADOR] Ningún técnico disponible para la ventana horaria del servicio.")
        return None

    # Separamos en:
    #   - técnicos sin servicios ese día (aún en casa matriz)
    #   - técnicos con servicios ese día (ya "en ruta")
    tecnicos_sin_servicio_en_dia = []
    tecnicos_con_servicio_en_dia = []

    for t in tecnicos_disponibles:
        if _tecnico_tiene_servicio_en_dia(t, servicio_nuevo):
            tecnicos_con_servicio_en_dia.append(t)
        else:
            tecnicos_sin_servicio_en_dia.append(t)

    # 1) Mientras haya técnicos sin servicio en el día: elegir uno al azar desde casa matriz
    if tecnicos_sin_servicio_en_dia:
        tecnico_elegido = random.choice(tecnicos_sin_servicio_en_dia)
        origen_dir = _direccion_empresa()  # todos parten de casa matriz

        print(
            f"[ASIGNADOR] Asignando por TURNO ALEATORIO desde casa matriz. "
            f"Técnico elegido: {tecnico_elegido.nombre} (ID {tecnico_elegido.id_tecnico}). "
            f"Origen: '{origen_dir}' → Cliente: '{dir_cliente}'"
        )

        asignacion = Asignacion(
            id_servicio=servicio_nuevo.id_servicio,
            id_tecnico=tecnico_elegido.id_tecnico,
        )
        db.session.add(asignacion)
        db.session.commit()

        # 🔴 IMPORTANTE: retornamos la Asignacion
        return asignacion

    # 2) Si TODOS los técnicos disponibles ya tienen al menos un servicio ese día,
    #    asignamos por distancia real.
    mejor_tecnico = None
    mejor_dist = None

    for t in tecnicos_con_servicio_en_dia:
        origen_dir = _origen_tecnico_en_el_dia(t, servicio_nuevo)
        if not origen_dir:
            continue

        lat_org, lon_org = geocodificar_direccion(origen_dir)
        if lat_org is None or lon_org is None:
            print(f"[ASIGNADOR] No se pudo geocodificar origen '{origen_dir}' para técnico {t.nombre}.")
            continue

        dist = distancia_km_osrm(lat_org, lon_org, lat_cli, lon_cli)
        if dist is None:
            print(f"[ASIGNADOR] No se pudo calcular distancia OSRM para técnico {t.nombre}.")
            continue

        print(
            f"[ASIGNADOR] Técnico {t.nombre} (ID {t.id_tecnico}) → "
            f"{dist:.2f} km desde '{origen_dir}' hasta '{dir_cliente}'."
        )

        if mejor_dist is None or dist < mejor_dist:
            mejor_dist = dist
            mejor_tecnico = t

    # Fallback: si no se pudo determinar mejor técnico por distancia,
    # usamos un técnico al azar entre los disponibles.
    if mejor_tecnico is None:
        print("[ASIGNADOR] No se pudo determinar mejor técnico por distancia. "
              "Usando fallback aleatorio entre técnicos disponibles.")
        tecnico_elegido = random.choice(tecnicos_disponibles)
        mejor_dist_info = None
    else:
        tecnico_elegido = mejor_tecnico
        mejor_dist_info = mejor_dist

    if mejor_dist_info is not None:
        print(
            f"[ASIGNADOR] Asignando por DISTANCIA. Técnico elegido: "
            f"{tecnico_elegido.nombre} (ID {tecnico_elegido.id_tecnico}). "
            f"Distancia ~ {mejor_dist_info:.2f} km."
        )
    else:
        print(
            f"[ASIGNADOR] Asignando técnico (fallback) sin distancia calculada: "
            f"{tecnico_elegido.nombre} (ID {tecnico_elegido.id_tecnico})."
        )

    asignacion = Asignacion(
        id_servicio=servicio_nuevo.id_servicio,
        id_tecnico=tecnico_elegido.id_tecnico,
    )
    db.session.add(asignacion)
    db.session.commit()

    # 🔴 Igual que antes: retornamos la Asignacion
    return asignacion

