from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Cliente(db.Model):
    __tablename__ = "cliente"

    id_cliente = db.Column(db.Integer, primary_key=True)
    nombre_razon_social = db.Column(db.String(120), nullable=False)
    rut = db.Column(db.String(12), nullable=False, unique=True)
    tipo_cliente = db.Column(db.String(50))
    tipo_contrato = db.Column(db.String(50))
    frecuencia_servicio = db.Column(db.String(50))
    direccion = db.Column(db.String(200))
    comuna = db.Column(db.String(100))
    region = db.Column(db.String(100))
    zona_geografica = db.Column(db.String(100))
    contacto = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    correo = db.Column(db.String(120))
    activo = db.Column(db.Boolean, default=True)
    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)

    servicios = db.relationship("Servicio", back_populates="cliente", lazy=True)


class Tecnico(db.Model):
    __tablename__ = "tecnico"

    id_tecnico = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    rut = db.Column(db.String(12), nullable=False, unique=True)
    especialidad = db.Column(db.String(80))
    zona_asignada = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    correo = db.Column(db.String(120))
    activo = db.Column(db.Boolean, default=True)

    asignaciones = db.relationship("Asignacion", back_populates="tecnico", lazy=True)


class Servicio(db.Model):
    __tablename__ = "servicio"

    id_servicio = db.Column(db.Integer, primary_key=True)
    id_cliente = db.Column(
        db.Integer,
        db.ForeignKey("cliente.id_cliente"),
        nullable=False,
    )

    tipo_plaga = db.Column(db.String(80))
    tipo_servicio = db.Column(db.String(80))
    prioridad = db.Column(db.String(20))  # alta / media / baja

    fecha_programada = db.Column(db.Date)
    hora_programada = db.Column(db.Time)
    duracion_estimada = db.Column(db.Integer, default=60)  # minutos

    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)
    estado_servicio = db.Column(db.String(20), default="pendiente")

    cliente = db.relationship("Cliente", back_populates="servicios")
    asignaciones = db.relationship("Asignacion", back_populates="servicio", lazy=True)

    factura = db.relationship(
        "Factura",
        back_populates="servicio",
        uselist=False,
        lazy=True,
    )

    indicador = db.relationship(
        "IndicadorServicio",
        back_populates="servicio",
        uselist=False,
        lazy=True,
    )

    historial = db.relationship(
        "HistorialServicio",
        back_populates="servicio",
        lazy=True,
        order_by="HistorialServicio.fecha_evento",
    )


class Asignacion(db.Model):
    __tablename__ = "asignacion"

    id_asignacion = db.Column(db.Integer, primary_key=True)
    id_servicio = db.Column(
        db.Integer,
        db.ForeignKey("servicio.id_servicio"),
        nullable=False,
    )
    id_tecnico = db.Column(
        db.Integer,
        db.ForeignKey("tecnico.id_tecnico"),
        nullable=False,
    )
    fecha_asignacion = db.Column(db.DateTime, default=datetime.utcnow)
    comentario = db.Column(db.String(200))

    servicio = db.relationship("Servicio", back_populates="asignaciones")
    tecnico = db.relationship("Tecnico", back_populates="asignaciones")


class Factura(db.Model):
    __tablename__ = "factura"

    id_factura = db.Column(db.Integer, primary_key=True)
    id_servicio = db.Column(
        db.Integer,
        db.ForeignKey("servicio.id_servicio"),
        nullable=False
    )

    # NUEVO / IMPORTANTE: que exista este campo
    numero_documento = db.Column(db.String(50))

    monto = db.Column(db.Float, nullable=False)
    tipo_documento = db.Column(db.String(20))          # boleta, factura
    medio_pago = db.Column(db.String(20))             # efectivo, transferencia, etc.
    estado_pago = db.Column(db.String(20), default="pendiente")
    fecha_emision = db.Column(db.DateTime, default=datetime.utcnow)

    servicio = db.relationship("Servicio", back_populates="factura")


class IndicadorServicio(db.Model):
    __tablename__ = "indicador_servicio"

    id_indicador = db.Column(db.Integer, primary_key=True)
    id_servicio = db.Column(
        db.Integer,
        db.ForeignKey("servicio.id_servicio"),
        nullable=False,
        unique=True,
    )
    tiempo_respuesta_horas = db.Column(db.Float)
    cumplimiento_agenda = db.Column(db.Boolean)
    reprogramado = db.Column(db.Boolean)
    satisfaccion_cliente_pct = db.Column(db.Integer)

    servicio = db.relationship("Servicio", back_populates="indicador")


class HistorialServicio(db.Model):
    __tablename__ = "historial_servicio"

    id_evento = db.Column(db.Integer, primary_key=True)
    id_servicio = db.Column(
        db.Integer,
        db.ForeignKey("servicio.id_servicio"),
        nullable=False,
    )
    fecha_evento = db.Column(db.DateTime, default=datetime.utcnow)

    tipo_evento = db.Column(db.String(50), nullable=False)
    descripcion = db.Column(db.Text, nullable=True)
    motivo = db.Column(db.String(200), nullable=True)
    url_evidencia = db.Column(db.String(255), nullable=True)
    registrado_por = db.Column(db.String(100), nullable=True)

    servicio = db.relationship("Servicio", back_populates="historial")
