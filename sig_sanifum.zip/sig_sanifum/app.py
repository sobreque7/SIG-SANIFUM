from flask import Flask, render_template
from models import db, Servicio
from routes_clientes import clientes_bp
from routes_tecnicos import tecnicos_bp
from routes_servicios import servicios_bp
from routes_facturas import facturas_bp
from routes_indicadores import indicadores_bp


def create_app():
    app = Flask(__name__)

    # Configuración BD (MySQL)
    app.config[
        "SQLALCHEMY_DATABASE_URI"
    ] = "mysql+pymysql://root:Seba4322@localhost/sig_sanifum"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.init_app(app)

    # BLUEPRINTS API
    app.register_blueprint(clientes_bp, url_prefix="/api")
    app.register_blueprint(tecnicos_bp, url_prefix="/api")
    app.register_blueprint(servicios_bp, url_prefix="/api")
    app.register_blueprint(facturas_bp, url_prefix="/api")
    app.register_blueprint(indicadores_bp, url_prefix="/api")

    # FRONTEND
    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/clientes")
    def clientes_page():
        return render_template("clientes.html")

    @app.route("/tecnicos")
    def tecnicos_page():
        return render_template("tecnicos.html")

    @app.route("/servicios")
    def servicios_page():
        return render_template("servicios.html")

    @app.route("/lista-servicios")
    def lista_servicios_page():
        # La tabla se llena vía JS desde /api/servicios
        return render_template("lista_servicios.html")

    @app.route("/facturas")
    def facturas_page():
        return render_template("facturas.html")

    # CLI para crear BD (solo si usas flask cli)
    @app.cli.command("init-db")
    def init_db():
        with app.app_context():
            db.create_all()
            print("Base de datos creada.")

    # DETALLE DEL SERVICIO
    @app.route("/servicios/<int:id_servicio>/detalle")
    def servicio_detalle_page(id_servicio):
        servicio = Servicio.query.get_or_404(id_servicio)

        tecnico = None
        if servicio.asignaciones:
            tecnico = servicio.asignaciones[0].tecnico

        factura = servicio.factura
        indicador = servicio.indicador
        historial = servicio.historial

        return render_template(
            "servicio_detalle.html",
            servicio=servicio,
            tecnico=tecnico,
            factura=factura,
            indicador=indicador,
            historial=historial,
        )

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
