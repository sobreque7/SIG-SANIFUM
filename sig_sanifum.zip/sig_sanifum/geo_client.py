# geo_client.py
import requests


def geocodificar_direccion(direccion: str):
    """
    Geocodifica una dirección de texto a (lat, lon) usando Nominatim (OpenStreetMap).
    No requiere API key. Limitado pero suficiente para el SIG académico.
    """
    if not direccion:
        return None, None

    url = "https://nominatim.openstreetmap.org/search"
    params = {
        "q": direccion,
        "format": "json",
        "limit": 1,
        "countrycodes": "cl",  # Chile
    }
    headers = {
        "User-Agent": "sig-sanifum/1.0 (proyecto-academico)"
    }

    try:
        resp = requests.get(url, params=params, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        if not data:
            return None, None

        lat = float(data[0]["lat"])
        lon = float(data[0]["lon"])
        return lat, lon

    except Exception as e:
        print(f"[GEO] Error geocodificando '{direccion}': {e}")
        return None, None


def distancia_km_osrm(lat1, lon1, lat2, lon2):
    """
    Calcula distancia real (km) de ruta en auto usando OSRM público.
    Tampoco requiere API key.
    """
    if None in (lat1, lon1, lat2, lon2):
        return None

    url = (
        f"http://router.project-osrm.org/route/v1/driving/"
        f"{lon1},{lat1};{lon2},{lat2}?overview=false"
    )

    try:
        resp = requests.get(url, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        if "routes" not in data or not data["routes"]:
            return None

        metros = data["routes"][0]["distance"]
        km = round(metros / 1000.0, 2)
        return km

    except Exception as e:
        print(f"[GEO] Error calculando distancia OSRM: {e}")
        return None
